require './usaepay'

tran=UmTransaction.new

# Merchants Source key must be generated within the console
tran.key="_necKE3o9LGKB403ExdIz7w05NK80993"

# Send request to sandbox server not production.  Make sure to comment or remove this line before
#  putting your code into production
tran.usesandbox=true

tran.card="4444555566667779"
tran.exp="0919"
tran.amount="1.00"
tran.invoice="1234"
tran.cardholder="Test T Jones"
tran.street="1234 Main Street"
tran.zip="90036"
tran.description="Online Order"
tran.cvv2="435"
tran.custom3="testest"
tran.pin="1234"
tran.savecard=true
#tran.proxyurl="http://localhost:3128"
tran.timeout="30"

p "Test Results:"

$stdout.flush

tran.Test

